# UMaize Theme



## 介绍

UMaize是一款基于[Jekyll主题TMaize](https://github.com/TMaize/tmaize-blog)的Jekyll主题。在原主题简洁轻快的基础上添加了更多的可定制性与其他特点。

你可以到https://moi-mo.github.io 查看主题效果（有所改动），欢迎添加友链。



## 特性

- Solarized Light主题配色
- 简约轻快
- 支持搜索
- 内置Valine评论系统，使用Valine实现内置微博客
- ...



## 使用 

请参看[using.md](https://github.com/moi-mo/UMaize/blob/master/using.md)。



## License

采用MIT协议。



